% Videoclub «Los Pajaritos»
% Ricardo Pérez
% Curso 2021/22

# Descripción general del proyecto

Explicar.

## Funcionalidad principal de la aplicación

Explicar.

## Objetivos generales

A diferencia de los casos de uso, los objetivos no tienen principio ni fin.

Por ejemplo:

* Objetivo: "gestionar los alquileres y las devoluciones de las películas".
* Casos de uso: "alquilar una película", "devolver una película".

# Elemento de innovación

Aspecto, función o tecnología novedosa o innovadora no tratada directamente
en clase y que será necesario investigar para desarrollar adecuadamente el
Proyecto.
